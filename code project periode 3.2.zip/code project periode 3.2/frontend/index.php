<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bioscoop|Homepage</title>
    <link rel="stylesheet" href="../view/css/style.css">
    <link rel="stylesheet" href="../view/css/film.css">
    <script type="module" src="script.js"></script>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
</head>
<body>
<!--hier geef ik de navigatiebar-->
    <header>
            <div class="navbar">
                <a class="active" href="index.php">Home</a>
                <a href="overzicht.php">Overzicht</a>
            </div>
    </header>
<!--hier geef ik de main section van de website-->
    <main>
        <h1>Welkom</h1>
    </main>
<!--hier maak ik de footer-->
    <footer>
        <div class="content">
            <div class="copyright">
                <strong>© Matthijs en Kevin IB3A - 2021</strong>
            </div>
            <div class="navigationlinks">
                <a href="index.php">Home</a>
                <a href="overzicht.php">Overzicht</a>
            </div>
        </div>
    </footer>
</body>
</html>