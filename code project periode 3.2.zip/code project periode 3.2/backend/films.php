<?php
    class film{
        

        public function ShowFilm(){  
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();

             #code...
             $query = "SELECT * FROM film"; //Query om film op te halen
             $stm = $conn->prepare($query);
             if($stm->execute()){
                   foreach($stm->fetchAll(PDO::FETCH_OBJ) as $film){ 
                echo "
                
                <div class='film'>
                        <img src='".$film->filmimage."'alt='#' style='width:100%'>
                        <div class='titel'
                        <p>'".$film->filmtitel."'</p>
                    </div>
                </div>
                    ";
                    }
            }
        }

        public function SearchFilm(){
            //niks doen
        }

        public function EditFilm(){
            //niks doen                
        }

        public function DeleteFilm(){
            //niks doen
        }

        public function AddFilm(){
            //niks doen
        }
    }

?>