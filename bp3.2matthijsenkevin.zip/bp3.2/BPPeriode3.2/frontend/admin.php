<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../recources/view/css/style.css">
    <link rel="stylesheet" href="../recources/view/css/film.css">
    <script type="module" src="script.js"></script>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

</head>

<body>

<header>
        <ul>
            <li><a href="../frontend/index.php">Home</a></li>
            <li><a href="../frontend/film.php">film</a></li>
            <li><a href="../frontend/admin.php">Admin</a></li>
        </ul>
</header>

<main>

<section class="filmSection">

   
<div class="searchBox">
  
        
       

        <form method="POST" class="containerInput">

                <div class="a">
                    <b>Naam: </b><input type='tekst' name='filmtitel' placeholder='filmtitel' />
                </div>

                <div class="b">
                    <b>filmbeschrijving: </b> <input type='tekst' name='filmbeschrijving' placeholder='filmbeschrijving' />
                </div>
                
                <div class="c">
                    <b>Prijs €: </b> <input type='tekst' name='prijs' placeholder='prijs' />
                </div>
                
                <div class="d">
                    <b>datum: </b> <input type='date' name='datum' placeholder='datum' />
                </div>
                
                <div class="e">
                    <b>Foto: </b> <input type='tekst' name='img' placeholder='link' />
                </div>
                
                <input class="f" type='submit' name='btnToevoegen' value='Toevoegen' />
               
        </form>
</div>

<form method="POST" class="containerfilmsAdmin">

        <?php
            require '../backend/php/filmClass.php';
            
            $PC = new film();
            $showfilm = $PC->ShowfilmAdmin();
            $delete = $PC->Deletefilm();
            $add = $PC->Addfilm();
            $edit = $PC->Editfilm();
        ?>

   
</form>
    


</section>


</main>

<footer>


    <div class="footerClaim">
        
        <div style="display: grid;">
            <i class="claim">© Matthijs en Kevin IB3A - 2021</i>
        </div>
        
    </div>

    <div class="footerLinks">
        <a href="../frontend/index.php">Home</a>
        <a href="../frontend/film.php">film</a>
        <a href="../frontend/admin.php">Admin</a> 
    </div>

</footer>


</body>


</html>