<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../recources/view/css/style.css">
    <link rel="stylesheet" href="../recources/view/css/film.css">
    <script type="module" src="script.js"></script>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

</head>

<body>

<header>
        <ul>
            <li><a href="../frontend/index.php">Home</a></li>
            <li><a href="../frontend/film.php">film</a></li>
            <li><a href="../frontend/admin.php">Admin</a></li>
        </ul>
</header>

<main class="mainHome">

    <section>

        <img class="imgHome" src="../recources/view/images/hallo.png" alt="#">

        <div class="sectionContainer">

            <H1>Welkom op deze bioscoopwebsite</H1>

            <p>Van matthijs meijboom en kevin roodbol voor een project in klas 3
            </p>

            <div>
                <a href="../frontend/index.php">Home</a>
                <a href="../frontend/film.php">film</a>
                <a href="../frontend/admin.php">Admin</a>
             </div>
           

        </div>

    </section>

</main>

<footer>


    <div class="footerClaim">
        
        <div style="display: grid;">
            <i class="claim">© Matthijs en Kevin IB3A - 2021</i>
        </div>
        
    </div>

    <div class="footerLinks">
        <a href="../frontend/index.php">Home</a>
        <a href="../frontend/film.php">film</a>
        <a href="../frontend/admin.php">Admin</a>
    </div>

</footer>
</body>
</html>