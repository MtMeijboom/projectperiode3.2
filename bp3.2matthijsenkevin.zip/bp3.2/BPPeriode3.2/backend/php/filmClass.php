<?php
    class film{
        

        public function ShowfilmAdmin(){  
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();

             #code...
             $query = "SELECT * FROM film"; //Query om film op te halen
             $stm = $conn->prepare($query);
             if($stm->execute()){
                   foreach($stm->fetchAll(PDO::FETCH_OBJ) as $film){ 
                echo "
                    <div class='mainContainer admin'>
                    <div class='".$film->filmtitel."'>
                        <b>film</b>
                    </div>
            
                    <div class='film content'>
                    <input name='PID' hidden readonly value='$film->filmID'/>
                        <img class='filmImg' src='".$film->filmimage."'  alt='#'>               
                        <div class='filmContent'>
                            <b>Titel: </b><input type='tekst' name='filmtitel' value='".$film->filmtitel."' />
                            <b>Beschrijving: </b> <input type='tekst' name='filmbeschrijving' value='".$film->filmbeschrijving."' />
                            <b>Datum: </b> <input type='date' name='datum' value='".$film->filmdatum."' />
                            <b>Prijs €: </b> <input type='tekst' name='prijs' value='".$film->filmprijs."' />
                            <b>Foto: </b> <input type='tekst' name='img' value='".$film->filmimage."' />
                        </div>
                    </div>
            
                    <div class='film adminButtons'>
                        <input type='submit' name='btnEdit' value='Wijzig' />
                        <input type='submit' name='btnDelete' value='Delete' />
                    </div>
                </div>
                    ";
                    }
            }
        }

        public function Searchfilm(){
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();

            if (isset($_POST['BtnSearch'])) 
                {
            
                    $zoek = "%".$_POST['ItemSearch']."%";
                    //query schrijven
                    $query = "SELECT * FROM film WHERE filmtitel like :waarde";
                    //inlezen van query
                    $stm = $conn->prepare($query);
                    // aliassen koppeen aan waarden
                    $stm->bindParam(":waarde", $zoek);
                    // uitvoeren van de query
                    if($stm->execute() == true){
                    //resultaten ophalen
                    $result = $stm->fetchAll(PDO::FETCH_OBJ);
                    //doorlopen van de resultaten
                    foreach($result as $event){
                        echo "
                        <div class='mainContainer user'>
                            <div class='film titel'>
                                <b>film</b>
                            </div>
            
                            <div class='film content'>
                                <img class='filmImg' src='".$event->filmimage."'  alt='#'>               
                                <div class='filmContent'>
                                <p>Titel: ".$event->filmtitel."</p>
                                <p>beschrijving: ".$event->filmbeschrijving."</p>
                                <p>Datum: ".$event->filmdatum."</p>
                                <p>Prijs: €".$event->filmprijs."</p>
                                </div>
                            </div>
            
                            <div class='film buttons'>
                                <a href=filmDetail.php?id=$event->filmID>Bekijk</a>
                                <input type='submit' name='btnBestel' value='Bestel' />
                            </div>
                        </div>
                    ";
                    }
                }else echo "Geen gegevens opgehaald!";
                }
        }


        public function filmDetail(){
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();

            if(isset($_GET['id'])){
        
                $id = $_GET['id']; 
                //query schrijven
                $query = "SELECT * FROM film WHERE filmID = :id";
                //query inlezen
                $stm = $conn->prepare($query);
                //aliassen koppelen aan de waarden
                $stm->bindParam(":id", $id);
                //query uitvoeren
                if($stm->execute() == true){
                  $film = $stm->fetch(PDO::FETCH_OBJ);
                  echo "  <img class='imgHome' src='$film->filmimage' alt='#'>

                  <div class='sectionContainer2'>
          
                      <H1>".$film->filmtitel."</H1>
          
                      <p>Beschrijving: ".$film->filmbeschrijving."</p>
                      <p>filmdatum: ".$film->filmdatum."</p>
                      <p>filmprijs: €".$film->filmprijs."</p>
          
                      <div>
                          <a href='film.php'><input type='submit' value='ga terug naar filmoverzicht' /></a>
                       </div>
                     
                  </div>";
                }else{echo "query kan niet worden uitgevoerd";}
        
            }
        }

        public function Editfilm(){
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();
            #code...
            if(isset($_POST['btnEdit'])){
      
                //Variabelen ophalen
                $fid = 0;
                $filmtitel = $_POST['filmtitel'];
                $filmbeschrijving = $_POST['filmbeschrijving'];
                $filmdatum = $_POST['datum'];
                $filmprijs = $_POST['prijs'];
                $filmimage = $_POST['img'];
                
                //STAP 1 - Query schrijven
                $query = "UPDATE film SET filmtitel = :filmtitel,
                     filmbeschrijving = :filmbeschrijving, filmdatum = :filmdatum,
                     filmprijs = :filmprijs, filmimage = :filmimage WHERE filmID = :id";
                //STAP 2 - query inlezen
                $stm = $conn->prepare($query);
                //STAP 3 - Aliassen koppelen aan waarden
                $stm->bindparam(":id", $fid);
                $stm->bindParam(":filmtitel", $filmtitel);
                $stm->bindParam(":filmbeschrijving", $filmbeschrijving);
                $stm->bindParam(":filmdatum", $filmdatum);
                $stm->bindParam(":filmprijs", $filmprijs);
                $stm->bindParam(":filmimage", $filmimage);
                
                //STAP 4 - Query uitvoeren naar de database
                if($stm->execute() == true){
                    echo "het werkt!";
                }else echo "Geen gegevens verstuurd!";
              } 
                
        }

        public function Deletefilm(){
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();
            #code...
            if(isset($_POST["btnDelete"])) {

                $filmID = $_POST["PID"];
            
                $query = "DELETE FROM film WHERE filmID = :filmId";
                $stm = $conn->prepare($query);
                $stm->bindparam(":filmId", $filmID);
                if ($stm->execute()) {
                    echo "Het verwijderen werkt";
            
                } else echo "ERROR!";
            }
        }

        public function Addfilm(){
            include_once 'config.php';
            $db = new Database();
            $conn = $db->connect();

            if (isset($_POST['btnToevoegen'])){ 
                $fid = 0;
                $filmtitel = $_POST['filmtitel'];
                $filmbeschrijving = $_POST['filmbeschrijving'];
                $filmdatum = $_POST['datum'];
                $filmprijs = $_POST['prijs'];
                $filmimage = $_POST['img'];
          
                $query = "INSERT into film VALUES (:FID,
                                                        :filmtitel,
                                                        :filmbeschrijving,
                                                        :filmdatum,
                                                        :filmprijs,
                                                        :foto)";

                $stm = $conn->prepare($query);
                $stm->bindParam(":FID", $fid);
                $stm->bindParam(":filmtitel", $filmtitel);
                $stm->bindParam(":filmbeschrijving", $filmbeschrijving);
                $stm->bindParam(":filmdatum", $filmdatum);
                $stm->bindParam(":filmprijs", $filmprijs);
                $stm->bindParam(":foto", $filmimage);
                
                if($stm->execute() == true){
                    echo "het werkt!";
                }else echo "Geen gegevens verstuurd!";
              } 
        }
    }

?>